from fastapi import FastAPI, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from backend.firestore import get_boards, create_task
from backend.models import Task
from backend.auth import verify_token

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict this to your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/boards")
def read_boards():
    return get_boards()

@app.post("/task")
def new_task(task: Task, request: Request):
    token = request.headers.get("Authorization")
    if not token:
        return {"error": "Missing token"}
    verify_token(token.replace("Bearer ", ""))
    return create_task(task)
