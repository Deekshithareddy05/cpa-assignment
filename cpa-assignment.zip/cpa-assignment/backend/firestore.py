# backend/firestore.py

import firebase_admin
from firebase_admin import credentials, firestore
from backend.models import Task

# Initialize Firebase Admin with service account
cred = credentials.Certificate("C:/Users/ASSUREX/Music/cpa-assignment/cpa-assignment-85189-bc2388c850f2.json")  # Replace with your real path
default_app = firebase_admin.initialize_app(cred)
db = firestore.client()

def get_boards():
    """
    Fetches all task boards from Firestore.
    Returns a list of task board documents.
    """
    boards_ref = db.collection("taskboards")
    boards = []
    for doc in boards_ref.stream():
        data = doc.to_dict()
        data['id'] = doc.id
        boards.append(data)
    return boards

def create_task(task: Task):
    """
    Creates a new task document in Firestore.
    Takes a Task object and stores it under 'tasks' collection.
    Returns task ID and confirmation.
    """
    tasks_ref = db.collection("tasks")
    new_task_ref = tasks_ref.document()
    new_task_ref.set(task.dict())
    return {"id": new_task_ref.id, "message": "Task created successfully"}

def get_tasks():
    """
    Fetches all tasks from Firestore.
    """
    tasks_ref = db.collection("tasks")
    return [doc.to_dict() for doc in tasks_ref.stream()]
