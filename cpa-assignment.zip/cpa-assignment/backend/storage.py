# backend/storage.py

import firebase_admin
from firebase_admin import credentials, storage
from fastapi import UploadFile, HTTPException
import uuid

# Initialize Firebase Admin only once
cred = credentials.Certificate("C:/Users/ASSUREX/Music/cpa-assignment/cpa-assignment-85189-bc2388c850f2.json")  # Replace with real path
firebase_admin.initialize_app(cred, {
    'storageBucket': 'your-project-id.appspot.com'  # Replace with your actual bucket name
})

bucket = storage.bucket()

def upload_file(file: UploadFile) -> str:
    """
    Uploads a file to Firebase Storage and returns its public URL.
    """
    try:
        file_id = str(uuid.uuid4())
        blob = bucket.blob(f"uploads/{file_id}_{file.filename}")
        blob.upload_from_file(file.file, content_type=file.content_type)
        blob.make_public()
        return blob.public_url
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

def download_file(file_path: str) -> bytes:
    """
    Downloads a file from Firebase Storage and returns its binary content.
    """
    try:
        blob = bucket.blob(file_path)
        if not blob.exists():
            raise HTTPException(status_code=404, detail="File not found")
        return blob.download_as_bytes()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")
