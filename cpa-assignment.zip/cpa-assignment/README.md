# CPA Assignment

This project is designed as part of a CPA (Cloud Programming Assignment), integrating Firebase services with a Python backend and an HTML/JS frontend.

## 📁 Project Structure

```
cpa-assignment/
│
├── .gitignore
├── README.md
├── firebase.json
├── cpa-assignment-85189-bc2388c850f2.json
│
├── .vscode/
│   └── settings.json
│
├── backend/
│   ├── auth.py
│   ├── firestore.py
│   ├── main.py
│   ├── models.py
│   ├── storage.py
│   └── requirements.txt
│
└── frontend/
    ├── index.html
    ├── login.html
    ├── register.html
    ├── dashboard.html
    ├── css/
    │   └── styles.css
    ├── js/
    │   ├── firebase-config.js
    │   ├── firebase-login.js
    │   ├── firebase-register.js
    │   └── main.js
    └── assets/
```

## 🚀 Features

- Firebase authentication integration
- Firestore database connectivity
- Firebase storage access
- Simple login/register system
- Frontend dashboard with Firebase interactivity

## 🧰 Backend Setup

1. Navigate to the `backend/` directory:
   ```bash
   cd backend
   ```

2. Create a virtual environment (optional but recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Run the backend server:
   ```bash
   python main.py
   ```

## 🌐 Frontend

Open the `frontend/index.html` file in a browser. Make sure Firebase project settings (in `firebase-config.js`) match your Firebase console configuration.

## 🔐 Firebase Configuration

- Ensure you have added the Firebase project key JSON (`cpa-assignment-85189-bc2388c850f2.json`) to your environment or referenced it appropriately.
- Configure your Firebase project rules for Firestore and Authentication for local development.

## ✅ Requirements

- Python 3.8+
- pip
- Firebase project credentials

## 📄 License

This project is for academic use only.
