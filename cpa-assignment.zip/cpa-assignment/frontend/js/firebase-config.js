import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyBwdZcweEzmFMQAr411fc2BDQMkz6nC2yY",
  authDomain: "cpa-assignment-85189.firebaseapp.com",
  projectId: "cpa-assignment-85189",
  storageBucket: "cpa-assignment-85189.firebasestorage.app",
  messagingSenderId: "503183843848",
  appId: "1:503183843848:web:26668b85bf72f83d4227bd",
  measurementId: "G-3QVNC8HZ1Z"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };
